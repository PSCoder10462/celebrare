Run index.html to see the output

*****

In case of any issue:
Final output (screen recording) is provided!
